let db=[
    {
        prod:"abc",
        amnt:2000
    },
    {
        prod:"cd",
        amnt:3000
    }
]
let sum=0
// let res = {db.filter(x=>x.amnt>1000)}
console.log(res);
// data={favouritesData.filter (x => x.rating>=4.5)}