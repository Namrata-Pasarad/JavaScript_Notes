//passing a funct as an arg
//convert all arr elmnt to square
// let a=[1,2,3,4,5,6,7,8,9]
// let res=[]
// for (let i = 0; i < a.length; i++) {
//     res=a[i]**2;
//     console.log(res); 
    
// }

// let square=a.map(x=>x**2)  //only v cn perform operation nd it ll never change length
// console.log(square);

// let add1=a.map( (i)=> i+1)
// console.log(add1);

//print array elmnt >5
// let a=[1,2,3,4,5,6,7,8,9]
// let res=[]
// for(let i=0;i<a.length;i++){
//     if(a[i]>5){
//         console.log(a[i]);
//     }
// }

// let result=a1.filter((x)=>{  //v cn apply condition nd it ll change length of arr depending upon the cond
//     return 
// })

// let result=a.filter(x=>x>5)
// console.log(result);

// let result=a.filter((x)=>x%2)//if v didn't mention x%2==0 it returns odd nor bcz 1%2==1 i.e 1 is true (boolean), 3%2=1 true ,2%2=0 false
// console.log(result);//returns the o/p if cond is satisfies else not

//sum of all values


let res=a.reduce((sum,x)=>sum+=x  )


console.log(res);




// let sum=0
// for (let i = 0; i < a.length; i++) {
//    sum+=a[i]   
// }
// console.log(sum);