// //asynchronous await and promises
// //set Timeout
// // let time=()=>{
// //     setTimeout(()=>{
// //         console.log("it executed..........!");
// //     }, 2000);
// // }
// // time()
 
let MSD=()=>{
    return "msd is here"
}

// let virat=()=>{
//     return "ee sala cup namde"
// }
// let virat=()=>{
//     setTimeout(()=>{    //undefined
//         return "ee sala cup namde"
//     }, 3000);
// }

let virat=()=>{
    return new Promise((resolve,reject)=>{  // promise ll be defined but its still in pending
        setTimeout(()=>{
            resolve("ee sala cup name")
        },3000);
    })
}

let ABD=()=>{
    return "mr.360 is here"
}

// // let result=()=>{       l
let result=async()=>{
    console.log(MSD());
    // console.log(virat());  
    console.log(await virat());
    console.log(ABD());
}
result()

// // setTimeout(()=>{
// //     //code
// // },timeout);
// function rev(str){
//     let reversed=''
//     for (let i =str.length-1;i>=0;i--){
//         reversed+=str[i]
// }
// return reversed
// }
// console.log(rev('hello'))

// for (let index = 0; index < =5; index++) {
//    console.log()
    
// }


// let a=[]
// let b=[]
// console.log(a==b)
// console.log(a===b)