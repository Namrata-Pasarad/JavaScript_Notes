// // //inheritance
// class Jspiders{
//     constructor(name,age,gender,empid){
//         this.name=name
//         this.age=age
//         this.gender=gender
//         this.empid=empid
//     }
//     yob=()=>`this year of birth is ${2022-this.age}`
// }

// class Faculty extends Jspiders{
//     constructor (name,age,gender,empid,salary,classes){
//         super(name,age,gender,empid)
//         this.salary=salary
//         this.classes=classes
//     }
// }
// let faculty1= new Faculty("asdf",24,"female",1234,100000)
// console.table(faculty1)
// console.table(faculty1.yob())


// class hr extends Jspiders{
//     constructor()
// }


//destrucuring
// let arr=[1,2,3,4,5]
// let a=arr[0]
// let b=arr[1]

// let  [a,]=arr //1,2,3,4,5
// console.log(a,);


// let [a,b]=[1,2,3,4,5] 
// console.log(a,b);//1,2


// let [a,b,c]=[1,2,3,4,5] //1,2,3
// console.log(a,b,c);
// let [a,,b]=arr[1,2,3,4,5]//1,3

// let[,,a]=[1,2,3,4,5]
// console.log(a);//3

let obj={
    name:"qwerty",
    age:22,
    roll:"developer"
}
let {a}=obj
console.log(a);//undefined

let {name}=obj
console.log(name);

// let {name,roll}=obj
// console.log(name,roll);




