let element=document.getElementById('title')
// let btn=document.getElementById('btn')
// element.style.display="none"

// let register=()=>{
//     element.style.display="block"
// }

// after clicking on btn the h1 ll display
// element.style.visibility="hidden"
// let register=()=>{
//     element.style.visibility="visible"
// }


// let register=()=>{
//     btn.style.color="blue"
//     btn.textContent="submitted"
      

//     element.textContent="event occured"
//     element.style.color="violet"
//     // document.getElementById('title').textContent="event occured"
//     console.log("you clicked........!");
// alert("registered")
// }



// in reset dec
// let value=document.getElementById('val')
// let increase=()=>{
//     value.textContent++
// }

// let decrease=()=>{
//     value.textContent--
// }

// let reset=()=>{
//     value.textContent=0
// }