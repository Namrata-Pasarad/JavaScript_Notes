// let a=10
// let b=10
// let c="100"
// console.log(a+b+c);


// let a="asdf"
// console.log(typeof(a));

// const a=10
// console.log(a)

let a=10
let b=10
console.log(a==b); //values true
console.log(a!=b)   //values false

// console.log(a**5);  //exponent operator a^5



