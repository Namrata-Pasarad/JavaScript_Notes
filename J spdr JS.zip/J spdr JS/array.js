// function odd(arr) {
//     console.log(arr[(arr.length-1)/2]);
    // console.log((arr.length-1)/2);  
// }
// odd([1,2,3,4,5])
                

// let i=2;
// do{
//     console.log("h");
// }while(i>5)


// let a=[10,'a',1.5,true]

// console.log(a[2]);//1.5
// console.log(a[5]);//undefined
// console.log(a.length);//no of elmnt in arr
// //to get last elmnt 
// console.log(a[a.length-1]); //instead of a[3]


let arr=[1,2,3,4,5]
// //arrayname.methodName()

// //includes
// let res=arr.includes(4)
// console.log(res)

// reverse
// let res=arr.reverse()
// console.log(res);

//join-
// let res=arr.join('*')
// console.log(res);


//splice
// arr.splice(2,1)//dlt the elmnt from index 2 to 2 elmnt
// arr.splice(1,0,10) //add the elmnt 100 to the 1st index
// arr.splice(1,0,100,200) //adding nd dlt at d same time

// arr.splice(0,arr.length)//dlt all elmnt 
// arr.splice(0)//do the same ''''
// arr.splice(1)//return the 1st elmnt
// console.log(arr);




// slice-part of arr from org arr
// let res=arr.slice(1,3)
// // let res=arr.slice(2)//print all elmnt from 2
// console.log(res)



//toString-convert arr to string
// let res=arr.toString()
// console.log(res);


// //arrayname.methodName()
//push
// arr.push(100,55,'a')
// console.log(arr);


//pop
// arr.pop() 
// console.log(arr);
// arr.pop() 
// arr.pop() 
// console.log(arr);




//shift-removes 1st elmnt in arr
// arr.shift()
// console.log(arr);

// arr.unshift(2,3)
// console.log(arr);

// arr[5]=500
// arr[6]=500  //5th index empty-item
// // arr[2]=100  //reintializing arr elmnt
// console.log(arr) //printing whole arr