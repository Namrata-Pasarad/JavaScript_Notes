function square(a){
    // console.log(a**2);
    return a**2
}
console.log(square(10));
// square(10)