// Object:collection of data that stores in d form of keys nd values

let database={
    name:"Timmy",
    age:24,
    designation:"developer",
    skills:["java","js"] //if we want to store mul values inside key we use array
    //nested objects
    // skills:{
    //     BE:"java",
    //     FE:"js"
    // }
}
// console.log(database);
// console.table(database)
// console.log(database.skills.FE);

// console.log(database.skills[1]) //want to fetch particular value

// console.log(database.age);//dot notation
// console.log(database['name']);//bracket notation
// console.log(database);
// // console.table(database)//table format
// database.skills="jav"//adding a new key
// database.age=22//re-initializing d value
// console.log(database);

// delete database.skills //deleting the keys
// console.log(database);


// let ObjectName={
//     key1:value1,
//     key2:{
//         key11:value11
//     }
   
// }

// let database=new Object();
// database.name="asdf"
// database.age=22
// console.log(database);

// Let objName=new object();
// objectName.key1=value1
// objectName.key2=value2

// console.log(objectName.key1);//dot notation
// console.log(objectName['key1']);//bracket notation

// delete ObjectName.key1
