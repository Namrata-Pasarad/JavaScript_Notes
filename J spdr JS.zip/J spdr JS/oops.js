//cls nd obj
class Database{
    constructor(firstName,lastName,age,designation,salary){
        this.firstName=firstName;
        this.lastName=lastName;
        this.age=age;
        this.designation=designation;
        this.salary=salary;
    }

    fullName=()=>`the full name is ${this.firstName} ${this.lastName}`
    yob=()=>`the person was born in ${2022-this.age}`
    annualSal=()=>`the annual salary is ${(this.salary*12)/100000} lpa`
}
let person1=new Database("tony","stark",22,"iron man",100000);
console.log(person1.fullName(),person1.yob());
console.log(person1.annualSal());
console.log(person1.yob());
console.table(person1);

// let person2=new Database("brunzo","wayne",28,"super Man",500000)
// console.log(person2.fullName());
// console.log(`the full anme of the person is ${person1.firstName }${person1.lastName}`);



// class InstaUser{
//     constructor(name,followers,following,post,relationshipSts, location){
//         this.name=name;
//         this.followers=followers;
//         this.following=following;
//         this.post=post;
//         this.relationshipSts=relationshipSts;
//         this.location=location;
//     }
//     fullDetails=()=>`the user name is ${this.name} who has ${this.followers} followers and located in ${this.location} and relationship sts is ${this.relationshipSts}`

//     activity=()=>{
//         if(this.post<=100){
//             return `user is inactive`
//         }else if(this.post>500){
//             return `user is addicted`
//         }else{
//             return `user is active`
//         }
//     }
//     relationshipStsCheck=()=>{
//         if(this.relationshipSts=="single"){
//             return this.fullDetails()
//         }else{
//             return 'never mind'
//         }
//     }
// }
// let user1=new InstaUser("Brucli",202,122,50,"divorced","uganda");
// console.log(user1.activity());
// console.log(user1.relationshipStsCheck());
// console.log(user1.fullDetails());
// let user2=new InstaUser("Nanu",500,350,250,"single");



// let object1=new classname(val1,val2)
// Objectname.methodname()