//arrow functions
// function cube(a){
//  return a**3
// }
// cube(2)


// let cube1=b=> `the cube of a is ${b}`
// console.log(cube1(5));

// let cube2=(b,a)=>b**3 //if v want 2 parm tn () are req
// console.log(cube1(5)); 

// let sum=(a,b)=>`the sum of a and b is ${a+b}`
// console.log(sum(10,20));


// let arr=(a)=>{
//     for (let i = 0;i < a.length; i++) {  
//     if(a[i]==1 && a[i+1]==3)
//     {
//         return true;
//     }
// }
// return false;
// }
// console.log(arr([1,3,2,4]));


// let arr=(a,res)=>{
//     for(let i=0;i<a.length;i++){
//         if(a[i]==1 && a[i+1]==3){
//             res=true
//         }
//     }
//     console.log(res);
// }
// arr([1,4,,5,1,3],false)

// let name="js"
// console.log("good mrng",js);
// console.log(`good mrng ${js}`); //template literals

// let name="js"
// console.log("good mrng",js);
// console.log(`good mrng ${js}`); //template literals


// function scope(){
//     for (let index = 0; index < 5; index++) {
//        console.log(index);   //0-4
        
//     }
//     console.log(index); //undefined: let is block scope
// }
// scope()


// function scope(){
//     for (const index = 0; index < 5; index++) { //const cannot be incre
//        console.log(index);
        
//     }
//     console.log(index); //undefined let is block scope
// }
// scope()


// function scope(){
//     if(10>5){
//         const i=10
//         console.log(i);//10
//     }
//     console.log(i);//undefined
// }
// scope()

// function scope1(){
//     for (var index = 0; index < 5; index++) {
//        console.log(index);       //0-4
        
//     }
//     console.log(index); //5 var is func scope
// }
// scope1()


// let i=10;   var i=10; const i=10//global scope
// function scope(){
//     console.log(i);
// }
// scope()

//  function scope(){ //global
//     for(let/var i=0;i<5;i++){
//         console.log(i);
//     }
//     console.log(i);
//  }

