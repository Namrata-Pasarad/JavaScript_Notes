
// var a=10;
// a=20
// var a=30
// console.log(a);

// let a=10
// a=20
// // let a=30
// console.log(a);


// const c=10;
// const c=20


// function sample() {
//     if (true) {
//         let a=10;
//         console.log(a);
//     }
//     console.log(a);
// }
// sample();
// console.log(a);


// var person="qwerty"
// var age=22
// var sal=1000
// console.log("the person name is ",person,"age: ",age,"sal: ",sal);
// console.log(`the person name is ${person} age: ${age} sal: ${sal}`);


// function add(a=0,b=0,c=0) {
//     console.log(a+b+c);
// }
// add(10)

let a
console.log(a);