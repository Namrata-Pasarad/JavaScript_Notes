let str="namana"
// let rev=""
// for(let i=0;i<str.length;i++){
//     rev=str[i]+rev
// }
// // for(let i=str.length-1;i>=0;i--){
// //     rev=rev+str.charAt(i)
// // }
// console.log(rev)

// if(str[0]==str[str.length-2]&& str[1]==str[str.length-1]){
//     console.log("same");
// }
// else{
// console.log("not same");
// }


//take str of even char, print middle 2 char
// function middle(s1) {
//     // console.log(s1.slice(1,3))
//    console.log(s1[(s1.length/2)-1]+s1[(s1.length)/2]); 
// }
// middle('java')
// middle("string")


// //check str palindrome or not
// function palindrome(s) {
//     let rev=""
//     for(let i=0;i<s.length;i++){
//         rev=s.charAt(i)+rev
//     }
//     if(s==rev){
//         console.log("palindrome");
//     }else{
//         console.log("not palindrome");
//     }
// }
// palindrome("gadaga")

// function palindrome(s1,s2) {
//     for(let i=s1.length-1;i>=0;i--){
//         s2+=s1[i]
//     }
//     if(s1==s2){
//         console.log("palindrome");
//     }
//     else{
//         console.log("not palindrome");
//     }
// }
// palindrome("gadag")


// let a="gadag"
// let rev=""
// for(let i=0;i<a.length;i++){
//     rev=a[i]+rev
// }
// if(a==rev){
//     console.log("palindrome");
// }
// else{
//     console.log("not palindrome");
// }