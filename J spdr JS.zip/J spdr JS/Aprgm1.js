//reverse string

// //---using built-in function
// let str="asdf"
// let res=str.split("").reverse().join("")
// console.log(res);


//---without using builtin function
// let str="asdf"
// let str1=""
// for(let i=0;i<str.length;i++){
//     str1=str[i]+str1
// }
// console.log(str1)


//nor of occurrence in a string

