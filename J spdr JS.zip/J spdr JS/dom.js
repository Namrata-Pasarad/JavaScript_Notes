//accessing with document obj 
// console.log("hello world");
// console.log(document.head);
// console.log(document.title);
// console.log(document.h1);//undefined bcz v hv mul h1 
// console.log(document.URL);

//domain:name given to d webpage


//manipulate
// document.title="new title"

//accessing by id names
// let elmnt=document.getElementById('title')  //if v hv mul same id tn 1st ll be our o/p
 //manipulating content through js/updating content
// elmnt.innerText="updated content"
// elmnt.textContent="new content"
// console.log(elmnt);

// document.getElementById('title').textContent='new content'

// console.log(document.getElementById('desc'));//h1#id

//classname

// let elmnt=document.getElementsByClassName('title')

// console.log(elmnt);
// elmnt[1].style.color="blue"
// elmnt[2].textContent="asdfghj"
// elmnt[1].innerText="new content"

// for (let i = 0; i < elmnt.length; i++) {
//     elmnt[i].style.color="blue"
  
// }


//tagname
// let elmnt=document.getElementsByTagName("h1")
// console.log(elmnt);

// elmnt[1].textContent="new content"//accessing only 1 elmnt by using index value


//query selector:it cn access both id ns cls elmnt
// let elmnt=document.querySelector('.title')//class 
// console.log(elmnt);

// let elmnt=document.querySelector('#desc')//id
// console.log(elmnt);

// let elmnt=document.querySelector('.title')//if v hv mul id/cls the 1st occurrence ll display

//if v want to display all the elmnt having same name tn v hv to use querySelectorAll
// let elmnt=document.querySelectorAll('.title')
// console.log(elmnt);