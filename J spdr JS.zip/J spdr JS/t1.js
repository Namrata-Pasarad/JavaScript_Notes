// function reverseString(str) { 
//     // Convert the string to an array of characters 
//     let chars = str.split(''); 
//     // Initialize two pointers, one at the start of the array and one at the end 
//     let left = 0; let right = chars.length - 1; 
//     // Swap the characters at the left and right pointers, and move the pointers towards the middle 
//     while (left < right) { 
//         let temp = chars[left]; 
//         chars[left] = chars[right]; 
//         chars[right] = temp; 
//         left++;
//          right--; 
//     } 
//         // Convert the array of characters back to a string and return it return 
//         chars.join(''); 
//     } 
//     reverseString("asdf")

// function reverseString(str) {
//     return str;
// }
// reverseString("hello");

// function reverseString(str) {

//     // empty string
//     let newString = "";
//     for (let i = str.length - 1; i >= 0; i--) {
//         newString += str[i];
//     }
//     return newString;
// }
// // reverseString("asdf")
// // take input from the user
// const string = "asdf";

// const result = reverseString(string);
// console.log(result);

// let a=[1,4,7]
// console.log(a.includes(4))

function find(a,e) {
    let res=a.includes(e)
    console.log(res)
}

find([1,4],1)