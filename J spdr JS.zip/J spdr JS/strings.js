// let str="java"
// let res=""
// for (let i = 0; i < str.length; i++) {
//     res=res+str[i]+str[i]
    
// }
// console.log(res);

//counting a in string
// let str='namrata'
// let c=0
// for(let i=0;i<str.length;i++){
//     if(str[i]=='a'){
//         c++
//     }
// }
// console.log(c);


// let str="java"
// let res=""
// //reverse the given str
// for(let i=str.length-1;i>=0;i--){
//     res=res+str.charAt(i)

//     // res=res+str[i]
// }
// console.log(res);


// let str="biriyani is great"
// // to print individual charcter
// for(let i=0;i<str.length;i++){
//     console.log(str[i])
// }




//string methods
//stringName.method()

//replace
//  let res=str.replace("i","a")
//  let res=str.replaceAll('i','e') //replace all the charcter
// let res=str.replace('great','yummy');
// console.log(res);


//toUpperCase()
// console.log(str.toUpperCase());
// console.log(str.toLowerCase());


// substring
// str.substring(0,3)
// console.log(str.substring(0,3));  //(start,end)

//indexOf
// console.log(str.indexOf('i'));//first occurance
// console.log(str.indexOf('i',3)); //from 0
// console.log(str.lastIndexOf('i',6)); //from length-1

//charAt()
// str.charAt(2)
// console.log(str.charAt(10));


// console.log(str[0])
// console.log(str.length);  //no of charcters


