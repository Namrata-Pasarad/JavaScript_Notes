//new keyword

// let person=new Object();
// person.name="jimmy",
// person.age=20,
// person.designation="ase"
// console.table(person);


// let series={
//     title:"Friends",
//     genre:"Comedy",
//     cast:['Rachel','joey'],
//     streaming:"netflix",
//     rating:"10"
// }
// //the series name is {name} which is straming on {stream}
// //that cast{},{}, and has the rating of {rating}

// console.log("the series name is ",series.title,"which is streaming on ",series.streaming,"that cast ",series.cast[0],",",series.cast[1],"and has the rating of",series.rating);
// console.log(`the series name is ${series.title}which is streaming on ${series.streaming}`);

//var
//operators
//flow control:decision nd looping
//arrays
//strings
//objects


//template literals
//arrow funct
//callback function
//scoping
//destructuring with arrays nd objects
//oops basics:cls,obj,inheritance
//dom:connecting js nd web(html,css)
//projects with API :weather app