let check=(a,b)=>{
    if(a.length==b.length){
        for (let i = 0; i < a.length; i++) {
            if (a[i]!=b[i]) {
                return false
            }
            
        }
        return true
        
    }else{
     return false       
    }
}
console.log(check([1,2,3],[1,2,3]));