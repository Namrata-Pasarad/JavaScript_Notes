// for(let i=10;i>=0;i--){
//     console.log(i);
// }

// for(let i=0;i>=-10;i--){
//     console.log(i);
// }


// for(let i=-10;i<=10;i++){
//     console.log(i);
// }

// for(let i=0;i<=10;i++){
//     if (i%2==0) {
//         console.log(i,"even");  
//     }
//     else{
//         console.log(i,"odd");
//     }
    
// }

// for(let i=0;i<=10;i+=2){
//         console.log(i);
//     }

// natural(5)
// function natural(natural) {
//     for(let i=1;i<=10;i++){
//         natural=natural+i;
//     }
//     console.log(natural)
// }
// natural(5)

// let a=10
// for(let i=1;i<=10;i++){
//     console.log("10*",i,"=",10*i)
// }

// let c=0
// for (let i = 1; i <=50; i++){
//     if (i%3==0 && i%5==0) {
//         //c++;
//        console.log(i) 
//     }
    
//     //console.log(c)  
// } 





//while
// let i=0
// while (i<5) {
//     i++
//     console.log("hello");
    
// }


// let i=0
// while (i<5) {
//     i++
//     console.log(i);
//     }
// let i=1,sum=0
// while(i<=20){
//     if(i%2==0){
//         sum=sum+i;
       
//     }
//     i++
//     // console.log(sum);
// }
// console.log(sum);
