//flow control statements
//decision
//if
// let a=100
// if(a>=100){
//     console.log('a is greater');
// }

// if else
// let a=10
// if (a%2==0) {
//     console.log(a,'even');
// } else {
//     console.log('odd')
// }

//if (condition) {
    
// } else if(condition) {
    
// }
// else{

// }

// let post=900
// if(post<=100){
//     console.log('in-active');
// }
// // else if(post>=100 && post<500){
//     else if(post>=500){
//     console.log('active');
// }
// else{
//     console.log('addicted');
// }




// let a=20,b=30,c=30
// // if(a==b && a==c && c==b){
// //     console.log('equal');
// // }

//  if (a>b && a>c) {
//     console.log(a,'a is greater');
// }
// else if(b>c && b>a){
//     console.log(b,'b is greater');
// }
// else if( c>a && c>b){
//     console.log(c,'c is greater');
// }
// else if(a==b && b==c && c==a){
//     console.log('all are equal');
// }
// else{
//     console.log('both 2 nor are equal');
// }



// let a=111,b,c
// // console.log(a%10);
// b=a%10
// console.log(b);
// c=a/100
// console.log(c);
// if(b==c){
//     console.log('2 digit are same');
// }
// else{
//     console.log('2 digit are not same');
// }



//switch(decision making stmnt) nd v cn use def antwhere in d switch stmnt
// let day="asd"
// switch (day) {
//     case "fri":
//         console.log("waiting for weekend");
//         break;
//     case "sat":
//         console.log(" go on party");
//         break;
//     case "sun":
//         console.log("sleep");
//         break;
//     default:
//         console.log("invalid day");
        
// }

// let a=10,b=2
// let operation='/'

// switch (operation) {
//     default:console.log('invalid nor');
//         break;
//     case '+':
//         console.log(a+b)
//         break;
//     case '-':
//         console.log(a-b);
//         break;
//     case '*':
//         console.log(a*b);
//         break;
//     case '/':console.log(a/b);
//             break;
    
// }