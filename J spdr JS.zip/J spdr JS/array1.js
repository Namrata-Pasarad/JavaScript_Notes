// let arr=[1,2,3,4,5]
// for(let i=0;i<arr.length;i++){
//     console.log(arr[i]);
// }

// let arr=[1,2,3,4,5]
// for(let i=arr.length-1;i>=0;i--){
//     console.log(arr[i]);
// }
//replace even nor by zero
// let arr=[1,2,3,4,5,6]
// for(let i=0;i<arr.length;i++){
//     if(arr[i]%2==0){
//         arr[i]=0;
//     }
//     // console.log(arr[i]);
// }
// console.log(arr)


let arr=[1,2,3,4,5]  //reversing an array
let a2=[]
// for(let i=0;i<arr.length;i++){
//     a2.unshift(arr[i])
//     console.log(a2);
// }
// console.log(a2);


// for(let i=arr.length-1;i>=0;i--){
//     a2.push(arr[i])
//     console.log(arr[i]);
// }
// console.log(a2);

// let arr=[1,2,3,4,5,6] //counting even nor
// let c=0
// for(let i=0;i<arr.length;i++){
//     if(arr[i]%2==0){
//         c++
//     }
// }
//  console.log('total even nor are: ',c);
// arr.splice(1,c)
// console.log(arr);


// let slog(a2);
// arr.splice(i,1)


// let arr=[1,2,3,4,5,6,7] 
// let c=0;
//     for (let i= 0; i < arr.length; i++) {
//         if(arr[i]==7){
//            c++ 
//         }
//     }
//     if(c>=1){
//         console.log(true);
//     }else{
//         console.log(false);
//     }
    

// let arr=[1,2,3,4,7,5,6]
// let res=false
// for(let i=0;i<arr.length;i++){
//     if(arr[i]==7){
//         res=true
//     }
// }
// console.log(res);
