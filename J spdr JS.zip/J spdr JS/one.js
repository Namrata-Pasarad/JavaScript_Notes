let btn=document.getElementById('btn')
let mode=()=>{
        if(btn.textContent== "Dark Mode" ){
            document.body.style.backgroundColor="black"
            document.body.style.color="white"
            btn.textContent="Light Mode"
                
        }

        else{
            document.body.style.backgroundColor="white"
            document.body.style.color="black"
            btn.textContent="dark Mode"
        }
    }
// let input = document.getElementById('asdf')
//     let submit=()=>{
//        document.getElementById('title').textContent=input.value
//     }

// let body=document.getElementById('body')
// let text=document.getElementById('text')
// let submit=()=>{
//     document.body.style.backgroundColor=body.value
//     document.body.style.color=text.value
// }

{/* <input id="body" type="text">
    document.getElementById('body').value */}


// let age=document.getElementById('age')//h2
// let input=document.getElementById('value')//i/p tag
// let presentYear=2022
// let calculate=()=>{
//     let currentAge=presentYear-input.value
//     age.textContent=currentAge//updating h2
//     // console.log(currentAge);

// }